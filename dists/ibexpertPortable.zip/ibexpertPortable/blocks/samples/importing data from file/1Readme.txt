1. Load the script into the Script Executive
2. Make necessary modifications
3. Press F9 to execute the script