To execute an IBEBlock you must load it into the SQL Editor
(or into the Script Executive if necessary) and press F9.

Before executing any IBEBlock please read the Readme.txt
if the one is presented. 