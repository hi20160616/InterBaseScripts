The example illustrates usage of cursors to compare
two tables in different databases.
