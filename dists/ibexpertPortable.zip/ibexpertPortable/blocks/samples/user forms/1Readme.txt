1. Copy all IBEBlocks into separate directory
2. Open TableDDL.ibeblock and change the path to FldTypeHTML.ibeblock
   in first statement. 
3. Load RunMe.ibeblock into the SQL Editor
4. Press F9 to execute the block