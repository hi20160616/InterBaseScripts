1. Copy all IBEBlocks into separate directory.
2. Load RunMe.ibeblock into the SQL Editor
3. Replace default values of CodeDir and ScriptFile
   input parameters with your own.
4. Press F9 to execute the block.


Note: this is just an example, therefore only generators,
domains and procedures will be extracted into script.