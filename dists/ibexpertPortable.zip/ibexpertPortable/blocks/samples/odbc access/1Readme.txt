1. Copy Demo.mdb and ODBCAcc.ibeblock into separate directory
2. Load ODBCAcc.ibeblock into the SQL Editor
3. Modify the path to Demo.mdb
4. Press F9 to execute the block