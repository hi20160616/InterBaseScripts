The example illustrates usage of EXECUTE IBEBLOCK
for comparation of two tables (table data) in different
databases.

Copy the text of the example into the SQL Editor and execute it.
